// JavaScript Document

jQuery(document).ready(function($) {
	//$( "#customize-info" ).after( "<div class=\"iexcel-promo\"><a href='//templatesnext.in/i-amaze/' target='_blank'>Go Premium</a></div>" );
	$( "#customize-info" ).after( "<div class=\"iexcel-promo-2\"><a href='//templatesnext.org/icreate/?page_id=1030' target='_blank'>Video Tutorials</a></div>" );
});